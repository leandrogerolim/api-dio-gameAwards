package me.dio.gameawards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioGameAwardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
