package me.dio.gameawards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DioGameAwardsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DioGameAwardsApplication.class, args);
	}

}
